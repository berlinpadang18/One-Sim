/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package routing.fuzzy;

import java.util.Collections;
import java.util.LinkedList;
import java.util.Random;
//import net.sourceforge.jFuzzyLogic.rule.FuzzyRuleSet;

/**
 * Test parsing an FCL file
 * @author pcingola@users.sourceforge.net
 */
public class testFuzzy {
    public static void main(String[] args) throws Exception {
       
        Random rnd = new Random(1);
        System.out.println(rnd);
        
    }
}